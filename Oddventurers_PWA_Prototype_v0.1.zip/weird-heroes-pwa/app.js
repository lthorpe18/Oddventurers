const DATA={
  who:[
    {name:'Knight',desc:'You are brave, sturdy and comfortable facing danger head-on.'},
    {name:'Witch',desc:'You understand magic, curses and things that should probably not be glowing.'},
    {name:'Robot',desc:'You are brilliant with machines and very difficult to frighten.'},
    {name:'Goblin',desc:'You are crafty, opportunistic and remarkably good at getting into places.'},
    {name:'Explorer',desc:'You know how to navigate, improvise and keep going when things get awkward.'},
    {name:'Bard',desc:'You can perform, persuade and turn attention exactly where you want it.'}
  ],
  weird:[
    {name:'Tiny',desc:'You can squeeze through spaces nobody else can.'},
    {name:'Haunted',desc:'A helpful-ish ghost follows you and can interact with spooky things.'},
    {name:'Elastic',desc:'You can stretch yourself far enough to reach improbable places.'},
    {name:'Invisible',desc:'You can disappear from sight when it really matters.'},
    {name:'Extremely Loud',desc:'You can make enough noise to distract almost anything.'},
    {name:'Magnetic',desc:'Metal objects have a habit of flying towards you.'},
    {name:'Two-Headed',desc:'You can watch, argue and think about two things at once.'},
    {name:'Ridiculously Tall',desc:'High shelves, walls and windows are suddenly much less impressive.'}
  ],
  talent:[
    {name:'Befriend',desc:'You have a knack for turning creatures and strangers into allies.'},
    {name:'Smash',desc:'You can break, force or batter things that refuse to cooperate.'},
    {name:'Sneak',desc:'You can move quietly and avoid unwanted attention.'},
    {name:'Fix',desc:'You can repair, rewire or bodge broken things back into usefulness.'},
    {name:'Climb',desc:'If there is any way upward, you can probably find it.'},
    {name:'Distract',desc:'You are excellent at making someone look anywhere except where they should.'},
    {name:'Track',desc:'You can follow trails, signs and clues that others would miss.'},
    {name:'Perform',desc:'You can entertain a crowd, calm nerves or create a convincing spectacle.'}
  ],
  power:[
    {name:'Teleport',desc:'Instantly get yourself somewhere that would otherwise be unreachable.'},
    {name:'Freeze',desc:'Stop a creature, object or hazard in place for a crucial moment.'},
    {name:'Copy',desc:'Briefly imitate another hero’s ready non-Power capability.'},
    {name:'Transform',desc:'Change yourself into a useful creature or shape for one problem.'},
    {name:'Shield',desc:'Protect the whole team from one dangerous consequence.'},
    {name:'Reverse',desc:'Make one moving, flowing or falling thing go the other way.'},
    {name:'Grow',desc:'Become enormous until the current problem is resolved.'},
    {name:'Time Skip',desc:'Skip past one immediate obstacle — but not an entire encounter chain.'}
  ],
  items:[
    {name:'A Very Long Rope',desc:'Useful for climbing, lowering, tying or pulling.'},
    {name:'Suspicious Magnet',desc:'Powerful enough to move inconvenient bits of metal.'},
    {name:'Enormous Umbrella',desc:'Useful against weather, falling things and unexpectedly for gliding.'},
    {name:'Convincing Disguise',desc:'At a distance, at least, you definitely belong here.'},
    {name:'Shiny Mirror',desc:'Reflects light, reveals reflections and is excellent for signalling.'},
    {name:'Pocket Shovel',desc:'A surprisingly effective answer to problems involving earth, sand or snow.'},
    {name:'Mystery Egg',desc:'Nobody knows what is inside. Once per game, declare one plausible helpful thing hatches from it, then discard it.'},
    {name:'Jar of Sticky Goo',desc:'Sticks two things together far more firmly than is sensible.'}
  ],
  encounters:[
    {title:'The Key Above the Door',structure:'Straight problem',story:'The iron door is locked. Its key hangs from a hook far above your heads, swaying just out of reach.',prompt:'Find a convincing way to get the key down.',solutions:'Elastic, Ridiculously Tall, Climb, Teleport, Grow, a rope, a clever magnetic solution, or another convincing way of reaching high.',fail:1},
    {title:'The Sleeping Ogre',structure:'Choose a route',story:'An enormous ogre is asleep across the only path. Every snore shakes dust from the ceiling.',prompt:'Slip past, distract the ogre, move it, or find another route.',solutions:'Invisible or Sneak can pass quietly. Extremely Loud, Distract, Bard or Perform could draw it away. Befriend may work if you wake it carefully. Teleport can bypass it.',fail:1},
    {title:'The Stuck Portcullis',structure:'Team combination',story:'A heavy gate has jammed halfway up. The release lever is on the far side where only a narrow gap remains.',prompt:'You need one hero to deal with the gate and another to reach the lever.',solutions:'Examples: Smash/Grow/strong Knight holds or lifts it while Tiny, Elastic, Goblin, Teleport or another suitable hero reaches the lever. Aim for two contributions.',fail:2},
    {title:'The Endless Staircase',structure:'Conserve or pay',story:'The staircase winds upward and upward and upward. You could spend something clever to avoid the exhausting climb… or simply endure it.',prompt:'Do you spend a useful capability, or save everything and take the setback?',solutions:'Teleport, Grow, Elastic, Explorer ingenuity, Climb, or another convincing shortcut. It is also always legal to take the Trouble instead.',fail:1},
    {title:'The Abandoned Workshop',structure:'Reward opportunity',story:'A strange machine is still humming in the corner. Something useful is rattling around inside it.',prompt:'If you can safely understand, open or dismantle the machine, you may search it.',solutions:'Robot, Fix, Witch for magical machinery, Smash if the group accepts a less delicate approach, Tiny to enter the casing, Magnetic where appropriate.',fail:0,reward:'item'},
    {title:'The Quiet Clearing',structure:'Recovery opportunity',story:'For once, nothing is chasing you. A sheltered clearing looks almost safe enough to stop for a moment.',prompt:'If someone can make camp genuinely safe, recover one spent non-Power capability.',solutions:'Explorer, Track, Befriend local creatures, Shield, Fix a shelter, Knight standing guard, or another convincing safety plan.',fail:0,recover:1},
    {title:'Something Is Following You',structure:'Escalating problem',story:'Branches snap behind you. Whatever is back there is getting closer, but stopping to deal with it will cost time and effort.',prompt:'Deal with the follower now, or carry the problem with you.',solutions:'Track to identify it, Befriend it, Invisible/Sneak to lose it, Extremely Loud or Perform to lure it away, Freeze, Teleport, or another convincing plan.',fail:0,condition:'Followed'},
    {title:'The Broken Rope Bridge',structure:'Choose a route',story:'The bridge has collapsed into the gorge. One frayed rope still reaches the far side.',prompt:'Reach the far side to secure the rope, improvise another crossing, or force your way through at a cost.',solutions:'Elastic, Climb, Teleport, Grow, Tiny with a clever route, Robot/Fix to rig something, or a suitable item.',fail:1,reward:'rope'},
    {title:'A Very Lonely Dragon',structure:'Reward opportunity',story:'The dragon blocks the tunnel. Oddly, it does not look angry. It looks bored.',prompt:'You could get past it — but making a friend might be more useful.',solutions:'Befriend is ideal. Bard/Perform, Witch, Haunted, Extremely Loud used entertainingly, a suitable gift/item, or a creative social solution.',fail:1,reward:'item'},
    {title:'The Room Filling With Jelly',structure:'Conserve or pay',story:'Purple jelly is pouring through cracks in the walls. It is already up to your knees and smells strongly of grapes.',prompt:'Stop the flow, escape quickly, or accept the messy consequences.',solutions:'Freeze, Fix, Smash an exit, Tiny through a drain, Teleport, Grow to lift others, Shield, Elastic, or a clever item.',fail:2},
    {title:'The Upside-Down Hallway',structure:'Team combination',story:'Gravity has decided the ceiling is now the floor. The exit is twenty feet above where your feet insist on being.',prompt:'Find a way to get the whole team to the new “floor”. Combining two heroes may be easiest.',solutions:'Climb, Elastic, Grow, Teleport, Witch, Robot/Fix using fixtures, rope plus a suitable hero, or two complementary capabilities.',fail:1},
    {title:'The Nervous Ghost',structure:'Recovery opportunity',story:'A translucent figure blocks the corridor, apologising repeatedly. It seems more frightened of you than you are of it.',prompt:'Help the ghost calm down or understand what it wants.',solutions:'Haunted, Witch, Befriend, Bard, Perform, Two-Headed listening patiently, or another kind social solution.',fail:1,recover:1},
    {title:'The Guard Who Loves Rules',structure:'Choose a route',story:'A guard demands Permit 47-B, signed by someone called “The Assistant Deputy Keeper of Doors.” This seems unlikely to be real.',prompt:'Convince, confuse, distract or bypass the guard.',solutions:'Bard, Perform, Distract, Convincing Disguise, Invisible, Teleport, Goblin cunning, Two-Headed argument, or another persuasive plan.',fail:1},
    {title:'The Magnetic Corridor',structure:'Straight problem',story:'Every metal object is being dragged toward a roaring machine at the far end of the hall — including some of you.',prompt:'Stop the pull or get everyone safely through.',solutions:'Magnetic may manipulate the pull, Robot/Fix can disable it, Witch, Reverse, Freeze, Teleport, Tiny avoiding machinery, or a clever non-metal solution.',fail:1},
    {title:'The Crumbling Statue',structure:'Reward opportunity',story:'A huge stone statue begins to topple. Behind it you glimpse a small chest that will be buried if you run.',prompt:'Save yourselves for free, or spend something useful to rescue the chest as well.',solutions:'Grow, Smash, Shield, Freeze, Elastic, Teleport, Knight, or another convincing way to stop/avoid the falling stone while recovering the chest.',fail:0,reward:'item'},
    {title:'The Maze That Keeps Moving',structure:'Escalating problem',story:'Every time you look away, the walls shift. You can keep wandering, but you may arrive at the finale badly delayed.',prompt:'Find a reliable way through, or accept that the maze has cost you.',solutions:'Explorer, Track, Two-Headed, Tiny using hidden gaps, Witch, Teleport, Reverse, or a clever marking/item strategy.',fail:1,condition:'Delayed'},
    {title:'The Flooded Passage',structure:'Team combination',story:'Fast water tears through the tunnel. A chain on the opposite wall could secure a safe crossing if someone can reach it.',prompt:'Get one hero to the chain and use another capability to protect or move the rest of the team.',solutions:'Teleport/Elastic/Climb reaches the chain; Shield/Grow/Knight/Freeze/Reverse controls danger; rope or other item can substitute. Aim for two contributions.',fail:2},
    {title:'The Door That Is Afraid of You',structure:'Straight problem',story:'The wooden door squeaks and pulls itself tighter into its frame whenever anyone approaches. It appears to be genuinely terrified.',prompt:'Reassure, trick, bypass or otherwise deal with a frightened door.',solutions:'Befriend, Bard, Perform, Tiny through a gap, Teleport, Witch, Invisible, or a particularly gentle creative approach.',fail:1}
  ],
  finales:[
    {title:'Finale: The Clockwork Beast',story:'At the heart of the ruins, a gigantic clockwork creature wakes. Gears spin, doors slam shut, and the floor begins to tilt toward a furnace.',stages:[
      {prompt:'First, stop the room itself from becoming impossible to stand in.',solutions:'Fix, Robot, Freeze, Reverse, Grow, Shield, or a convincing control solution.'},
      {prompt:'Then create a way to reach the creature’s glowing control panel.',solutions:'Elastic, Climb, Tiny, Teleport, Ridiculously Tall, Grow, rope, teamwork or another reach solution.'},
      {prompt:'Finally, shut it down without letting the furnace take the whole team with it.',solutions:'Robot/Fix, Witch, Smash, Freeze, Shield, Copy of something useful, a clever item, or a convincing combination.'}
    ]},
    {title:'Finale: The Castle Wakes Up',story:'The entire castle stretches, yawns and decides it would rather be somewhere else. Corridors twist while towers begin walking away on enormous stone legs.',stages:[
      {prompt:'Keep the team together while the rooms rearrange around you.',solutions:'Explorer, Track, Elastic, Extremely Loud, Two-Headed, Shield, or teamwork.'},
      {prompt:'Reach the control bell hanging outside the highest tower.',solutions:'Climb, Elastic, Ridiculously Tall, Grow, Teleport, rope, or a creative route.'},
      {prompt:'Convince, force or trick the castle into sitting back down.',solutions:'Witch, Bard/Perform, Smash, Robot/Fix, Befriend interpreted creatively, Reverse, or a strong combination.'}
    ]}
  ]
};

const KEY='oddventurers-state-v1';
const rand=a=>a[Math.floor(Math.random()*a.length)];
const shuffle=a=>[...a].sort(()=>Math.random()-.5);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
let state=load()||{screen:'home'};
function load(){try{return JSON.parse(localStorage.getItem(KEY))}catch{return null}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function setState(p){state={...state,...p};save();render()}
function newGame(players){
  state={screen:'build',players,building:0,heroes:Array.from({length:players},(_,i)=>({name:`Hero ${i+1}`,modules:{},spent:{}})),draft:{},trouble:0,maxTrouble:5,items:[],conditions:[],adventure:[],index:0,finale:null,finaleStage:0};
  makeDraft();save();render();
}
function makeDraft(){
  const hero=state.heroes[state.building]; state.draft={};
  ['who','weird','talent','power'].forEach(k=>state.draft[k]=shuffle(DATA[k]).slice(0,2));
  hero.modules={}; hero.spent={};
}
function choose(k,name){state.heroes[state.building].modules[k]=DATA[k].find(x=>x.name===name);save();render()}
function buildReady(){return ['who','weird','talent','power'].every(k=>state.heroes[state.building].modules[k])}
function nextHero(){
  if(!buildReady())return;
  if(state.building<state.players-1){state.building++;makeDraft();save();render()} else startAdventure();
}
function startAdventure(){
  state.adventure=shuffle(DATA.encounters).slice(0,8);state.finale=rand(DATA.finales);state.screen='adventure';state.index=0;state.finaleStage=0;save();render();
}
function toggleSpent(i,k){state.heroes[i].spent[k]=!state.heroes[i].spent[k];save();render()}
function addTrouble(n){state.trouble=Math.max(0,Math.min(state.maxTrouble,state.trouble+n));save(); if(state.trouble>=state.maxTrouble)state.screen='lost';save();render()}
function randomItem(specific){let item;if(specific==='rope') item=DATA.items[0]; else item=rand(DATA.items.filter(x=>!state.items.some(y=>y.name===x.name))); if(item) state.items.push(item);save();render()}
function removeItem(i){state.items.splice(i,1);save();render()}
function refreshOne(){state.screen='refresh';save();render()}
function doRefresh(hi,k){state.heroes[hi].spent[k]=false;state.screen='adventure';advance();}
function addCondition(c){if(!state.conditions.includes(c))state.conditions.push(c);save();advance()}
function advance(){state.index++; if(state.index>=state.adventure.length){state.screen='finale'} save();render()}
function finaleAdvance(){state.finaleStage++; if(state.finaleStage>=state.finale.stages.length)state.screen='won';save();render()}
function reset(){localStorage.removeItem(KEY);state={screen:'home'};render()}

function header(extra=''){return `<div class="topbar"><div><div class="brand">Oddventurers</div><div class="sub">prototype v0.1 ${extra}</div></div><button class="btn secondary small" onclick="reset()">New game</button></div>`}
function trouble(){return `<div><div class="row"><b>Team Trouble</b><span>${state.trouble}/${state.maxTrouble}</span></div><div class="trouble">${Array.from({length:state.maxTrouble},(_,i)=>`<i class="${i<state.trouble?'filled':''}"></i>`).join('')}</div></div>`}
function heroCard(h,i,interactive=true){return `<div class="card hero"><div class="row"><div><div class="tag">${esc(h.modules.who?.name||'Hero')}</div><h2>${esc(h.name)}</h2></div><div class="emoji">${['🧙','🤖','🛡️','👺'][i%4]}</div></div>${['who','weird','talent','power'].map(k=>{const m=h.modules[k];if(!m)return'';const sp=h.spent[k];return `<button ${interactive?'':'disabled'} class="module ${sp?'spent':''}" style="width:100%;text-align:left;margin-top:8px" onclick="toggleSpent(${i},'${k}')"><div class="module-type">${k==='who'?'Who':k==='weird'?'Unusual':k==='talent'?'Talent':'Power'} ${sp?'• SPENT':'• READY'}</div><div class="module-title">${esc(m.name)}</div><p>${esc(m.desc)}</p></button>`}).join('')}</div>`}
function items(){if(!state.items.length)return `<div class="card"><h3>Shared items</h3><p class="muted">You haven’t found anything useful yet.</p></div>`;return `<div class="card"><h3>Shared items</h3><div class="stack">${state.items.map((it,i)=>`<div class="item"><div class="row"><b>${esc(it.name)}</b><button class="btn secondary small" onclick="removeItem(${i})">Use / discard</button></div><div class="small">${esc(it.desc)}</div></div>`).join('')}</div></div>`}
function teamMini(){return `<details class="card"><summary><b>Show the team’s capabilities</b></summary><div class="grid-heroes" style="margin-top:12px">${state.heroes.map((h,i)=>heroCard(h,i,true)).join('')}</div></details>${items()}`}
function reference(e){return `<button class="btn secondary" style="width:100%" onclick="document.getElementById('ref').classList.toggle('hidden')">Check intended solutions</button><div id="ref" class="reference hidden"><b>Designer/reference answer:</b><br>${esc(e.solutions)}<hr><span class="muted">This is guidance, not a whitelist. If your idea clearly makes sense, use it. For a stretch, let the group decide.</span></div>`}
function home(){return `<div class="shell">${header()}<div class="card center"><div class="emoji">🧩⚔️👻</div><h1>Build something ridiculous.</h1><p class="lead">Make a weird hero, combine the team’s strange capabilities, then ration them through an unknown adventure.</p></div><div class="card"><h2>How many heroes?</h2><p class="muted">For phone play, each person can build one hero and pass the phone around.</p><div class="grid2"><button class="btn" onclick="newGame(2)">2 heroes</button><button class="btn" onclick="newGame(3)">3 heroes</button><button class="btn" onclick="newGame(4)">4 heroes</button><button class="btn secondary" onclick="newGame(1)">Solo test</button></div></div><div class="card"><h3>Core rule</h3><p>When an adventure problem appears, propose a capability that could genuinely solve it. If the group accepts it, <b>spend that capability by tapping its card</b>. Or keep your powers ready and accept the setback.</p></div></div>`}
function build(){const h=state.heroes[state.building];return `<div class="shell">${header(`• build ${state.building+1}/${state.players}`)}<div class="card"><div class="tag">Character creation</div><h1>Make Hero ${state.building+1}</h1><p>Choose one card from each pair. You’re building a person, not a stat sheet.</p></div>${['who','weird','talent','power'].map(k=>`<div class="card"><h3>${k==='who'?'Who are you?':k==='weird'?"What’s unusual about you?":k==='talent'?'What are you good at?':'What impossible thing can you do?'}</h3><div class="grid2">${state.draft[k].map(m=>`<button class="module choice ${h.modules[k]?.name===m.name?'selected':''}" onclick="choose('${k}','${esc(m.name)}')"><div class="module-title">${esc(m.name)}</div><p>${esc(m.desc)}</p></button>`).join('')}</div></div>`).join('')}<div class="bottom"><div class="bottom-inner"><div class="btn secondary center">${Object.keys(h.modules).length}/4 chosen</div><button class="btn good" ${buildReady()?'':'disabled'} onclick="nextHero()">${state.building===state.players-1?'Start adventure':'Next hero'}</button></div></div></div>`}
function adventure(){const e=state.adventure[state.index];const pct=(state.index/state.adventure.length)*100;return `<div class="shell">${header(`• encounter ${state.index+1}/${state.adventure.length}`)}${trouble()}<div class="progress"><div style="width:${pct}%"></div></div>${state.conditions.length?`<div class="card"><div class="tag">Current complications</div>${state.conditions.map(c=>`<span class="pill">⚠️ ${esc(c)}</span>`).join('')}</div>`:''}<div class="card encounter"><div class="tag">${esc(e.structure)}</div><h1>${esc(e.title)}</h1><p class="story">${esc(e.story)}</p><div class="effect"><b>What do you do?</b><br>${esc(e.prompt)}</div>${e.reward?`<div class="effect"><b>Opportunity:</b> solve it and you may gain something useful.</div>`:''}${e.recover?`<div class="effect"><b>Recovery:</b> a clean solution lets you refresh one spent non-Power capability.</div>`:''}${reference(e)}</div>${teamMini()}<div class="bottom"><div class="bottom-inner"><button class="btn good" onclick="solvedCurrent()">We solved it</button><button class="btn bad" onclick="failedCurrent()">Take the setback</button></div></div></div>`}
function solvedCurrent(){const e=state.adventure[state.index];if(e.reward){randomItem(e.reward); if(e.recover)refreshOne(); else advance()}else if(e.recover){refreshOne()}else advance()}
function failedCurrent(){const e=state.adventure[state.index]; if(e.condition){addCondition(e.condition);return} if(e.fail)addTrouble(e.fail); if(state.screen!=='lost')advance()}
function refresh(){let choices=[];state.heroes.forEach((h,hi)=>['who','weird','talent'].forEach(k=>{if(h.spent[k])choices.push({hi,k,h,m:h.modules[k]})}));if(!choices.length){state.screen='adventure';advance();return''}return `<div class="shell">${header()}<div class="card"><h1>Catch your breath</h1><p>Refresh one spent non-Power capability.</p></div><div class="stack">${choices.map(c=>`<button class="module choice" onclick="doRefresh(${c.hi},'${c.k}')"><div class="module-type">${esc(c.h.name)}</div><div class="module-title">${esc(c.m.name)}</div><p>${esc(c.m.desc)}</p></button>`).join('')}</div></div>`}
function finale(){const f=state.finale,s=f.stages[state.finaleStage];return `<div class="shell">${header(`• finale ${state.finaleStage+1}/${f.stages.length}`)}${trouble()}<div class="card encounter"><div class="tag">Finale</div><h1>${esc(f.title)}</h1>${state.finaleStage===0?`<p class="story">${esc(f.story)}</p>`:''}<div class="effect"><b>Stage ${state.finaleStage+1}</b><br>${esc(s.prompt)}</div>${reference(s)}</div>${teamMini()}<div class="bottom"><div class="bottom-inner"><button class="btn good" onclick="finaleAdvance()">Solved</button><button class="btn bad" onclick="addTrouble(2); if(state.screen!=='lost') finaleAdvance()">Fail: +2 Trouble</button></div></div></div>`}
function end(win){return `<div class="shell">${header()}<div class="card center"><div class="emoji">${win?'🏆':'💥'}</div><h1>${win?'You made it!':'The adventure got you.'}</h1><p class="lead">${win?'Your deeply questionable collection of heroes somehow survived.':'The team ran out of room for things to go wrong.'}</p><p>${win?'The important question: what completely different heroes do you want to build next?':'Rebuild the team and see whether a stranger combination does better.'}</p><button class="btn good" onclick="reset()">Build another team</button></div><div class="grid-heroes">${state.heroes.map((h,i)=>heroCard(h,i,false)).join('')}</div></div>`}
function render(){const app=document.getElementById('app');if(!app)return;let html='';switch(state.screen){case'home':html=home();break;case'build':html=build();break;case'adventure':html=adventure();break;case'refresh':html=refresh();break;case'finale':html=finale();break;case'won':html=end(true);break;case'lost':html=end(false);break;default:html=home()}app.innerHTML=html;window.scrollTo(0,0)}
if('serviceWorker'in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}
render();
